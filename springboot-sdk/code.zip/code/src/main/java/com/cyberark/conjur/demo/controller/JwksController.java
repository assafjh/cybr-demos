package com.cyberark.conjur.demo.controller;

import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.RSAKey;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyPair;
import java.security.interfaces.RSAPublicKey;
import java.util.Collections;

@Controller
@RequiredArgsConstructor
@Slf4j
public class JwksController {

    private final KeyPair keyPair; // Injected RSA KeyPair
    private final String jwksFilePath = "/path/to/jwks.json"; // Update path as needed

    /**
     * Endpoint to serve the JWKS (JSON Web Key Set).
     *
     * @return JWKS as a JSON string
     */
    @GetMapping("/.well-known/jwks.json")
    public String getJwks() {
        log.info("Serving JWKS from endpoint");

        File jwksFile = new File(jwksFilePath);
        if (jwksFile.exists()) {
            // Return the existing JWKS file content
            try {
                String jwks = Files.readString(Paths.get(jwksFilePath));
                log.debug("Returning existing JWKS: {}", jwks);
                return jwks;
            } catch (IOException e) {
                log.error("Error reading existing JWKS file: ", e);
                throw new RuntimeException("Failed to read existing JWKS file.", e);
            }
        }

        // Generate and save a new JWKS if the file does not exist
        try {
            RSAKey rsaKey = new RSAKey.Builder((RSAPublicKey) keyPair.getPublic())
                    .keyID("key-id") // Replace with a unique key ID
                    .build();

            JWKSet jwkSet = new JWKSet(Collections.singletonList(rsaKey));
            String jwks = jwkSet.toJSONObject().toString();

            // Save the JWKS to a file
            Files.writeString(Paths.get(jwksFilePath), jwks);
            log.debug("Generated and saved new JWKS: {}", jwks);

            return jwks;
        } catch (Exception e) {
            log.error("Error generating JWKS: ", e);
            throw new RuntimeException("Failed to generate JWKS.", e);
        }
    }

    /**
     * Method to handle JWKS initialization (called by SecretController in init mode).
     *
     * @return Success message
     */
    public String initializeJwks() {
        File jwksFile = new File(jwksFilePath);
        if (jwksFile.exists()) {
            log.info("JWKS file already exists at {}", jwksFilePath);
            return "JWKS already exists!";
        }

        try {
    
