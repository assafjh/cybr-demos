package com.cyberark.conjur.demo.controller;

import com.cyberark.conjur.demo.config.SecretsConfig;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequiredArgsConstructor
@Slf4j
public class SecretController {

    private final SecretsConfig secretsConfig; // Use SecretsConfig to retrieve logical names and resolved secrets
    private final JwksController jwksController; // Delegate JWKS operations to JwksController

    @GetMapping("/secrets")
    public Map<String, String> getSecrets() {
        log.info("Starting secrets retrieval process");

        // Check for 'init' mode
        String initMode = System.getProperty("mode");
        if ("init".equalsIgnoreCase(initMode)) {
            log.info("Init mode detected. Delegating JWKS handling to JwksController...");
            String message = jwksController.initializeJwks();
            log.info("Exiting application after init: {}", message);
            System.exit(0); // Exit after init process is complete
        }

        try {
            // Retrieve secrets and log them
            Map<String, String> retrievedSecrets = new HashMap<>();
            retrievedSecrets.put("secret1", secretsConfig.getSecret1());
            retrievedSecrets.put("secret2", secretsConfig.getSecret2());
            retrievedSecrets.put("secret3", secretsConfig.getSecret3());

            retrievedSecrets.forEach((key, value) -> log.info("Retrieved secret: {} = {}", key, value));
            return retrievedSecrets;
        } catch (Exception e) {
            log.error("Error while retrieving secrets: ", e);
            throw new RuntimeException("Error occurred while retrieving the secrets.", e);
        }
    }
}
