package com.cyberark.conjur.demo.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "conjur.secrets")
@Data
public class SecretsConfig {
    private String secret1;
    private String secret2;
    private String secret3;
}
