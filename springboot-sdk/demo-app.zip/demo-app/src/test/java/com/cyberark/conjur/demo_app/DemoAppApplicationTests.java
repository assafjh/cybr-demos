package com.cyberark.conjur.demo_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
